// =====================================================
// Landing page carousel
// Renders project cards from PROJECTS (data.js) in a "coverflow"
// layout: the selected project sits centered and full-size, the
// rest shrink and fade based on their distance from the middle.
// =====================================================
const track = document.getElementById('carousel-track');
const titleEl = document.getElementById('landing-title');
const backdrop = document.getElementById('hero-backdrop');
const viewLink = document.getElementById('view-project-link');
const prevBtn = document.getElementById('carousel-prev');
const nextBtn = document.getElementById('carousel-next');

let selectedIndex = 0;

function renderCarousel() {
  track.innerHTML = '';

  PROJECTS.forEach((project, index) => {
    const offset = index - selectedIndex;
    const isSelected = offset === 0;

    const card = document.createElement('div');
    card.className = 'carousel-card';
    card.appendChild(createProjectImage(project.heroImage, project.name, 'carousel-card-image'));

    const translateX = offset * 150;
    const scale = isSelected ? 1 : Math.max(0.6, 1 - Math.abs(offset) * 0.15);
    const opacity = Math.max(0, 1 - Math.abs(offset) * 0.35);

    card.style.transform = `translate(-50%, -50%) translateX(${translateX}px) scale(${scale})`;
    card.style.opacity = String(opacity);
    card.style.zIndex = String(100 - Math.abs(offset));

    // Clicking the centered card goes to its project page.
    // Clicking a side card brings that project to the center instead.
    card.addEventListener('click', () => {
      if (isSelected) {
        goToProject(project.id);
      } else {
        selectedIndex = index;
        renderCarousel();
      }
    });

    track.appendChild(card);
  });

  const current = PROJECTS[selectedIndex];
  titleEl.textContent = current.name;
  viewLink.href = `project.html?id=${current.id}`;
  updateBackdrop(current.heroImage);
}

function updateBackdrop(src) {
  backdrop.innerHTML = '';
  const img = document.createElement('img');
  img.src = src;
  img.alt = '';
  // Decorative background — if it's missing, just leave it blank
  // rather than showing a text placeholder over the whole page.
  img.addEventListener('error', () => img.remove());
  backdrop.appendChild(img);
}

function goToProject(id) {
  window.location.href = `project.html?id=${id}`;
}

function showPrev() {
  selectedIndex = (selectedIndex - 1 + PROJECTS.length) % PROJECTS.length;
  renderCarousel();
}

function showNext() {
  selectedIndex = (selectedIndex + 1) % PROJECTS.length;
  renderCarousel();
}

prevBtn.addEventListener('click', showPrev);
nextBtn.addEventListener('click', showNext);

document.addEventListener('keydown', (event) => {
  if (event.key === 'ArrowLeft') showPrev();
  if (event.key === 'ArrowRight') showNext();
});

renderCarousel();
