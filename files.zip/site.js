// =====================================================
// Shared site behavior — loaded on every page.
// =====================================================

// ---------- Dark mode ----------
// Order of preference: what the visitor chose last time (saved in
// localStorage) -> their OS-level light/dark setting -> light.
const themeToggle = document.getElementById('theme-toggle');
const root = document.documentElement;

function getStoredTheme() {
  try {
    return localStorage.getItem('theme');
  } catch (e) {
    return null; // e.g. private browsing — just skip persistence
  }
}

function storeTheme(theme) {
  try {
    localStorage.setItem('theme', theme);
  } catch (e) {
    // Nothing we can do — the toggle still works for this visit,
    // it just won't be remembered on the next one.
  }
}

function applyTheme(theme) {
  if (theme === 'dark') {
    root.setAttribute('data-theme', 'dark');
    themeToggle.setAttribute('aria-pressed', 'true');
    themeToggle.setAttribute('aria-label', 'Switch to light mode');
  } else {
    root.removeAttribute('data-theme');
    themeToggle.setAttribute('aria-pressed', 'false');
    themeToggle.setAttribute('aria-label', 'Switch to dark mode');
  }
}

const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
applyTheme(getStoredTheme() || (systemPrefersDark ? 'dark' : 'light'));

themeToggle.addEventListener('click', () => {
  const isDark = root.getAttribute('data-theme') === 'dark';
  const newTheme = isDark ? 'light' : 'dark';
  applyTheme(newTheme);
  storeTheme(newTheme);
});

// ---------- Footer year ----------
const yearEl = document.getElementById('year');
if (yearEl) {
  yearEl.textContent = new Date().getFullYear();
}

// ---------- Image with a graceful fallback ----------
// If an image file doesn't exist yet, this shows a plain labeled
// placeholder instead of a broken image icon. Once a real file
// exists at the given path, it just appears automatically — no
// code changes needed.
function createProjectImage(src, altText, extraClass) {
  const wrapper = document.createElement('div');
  wrapper.className = 'img-wrapper' + (extraClass ? ' ' + extraClass : '');

  const img = document.createElement('img');
  img.src = src;
  img.alt = altText;

  img.addEventListener('error', () => {
    wrapper.classList.add('img-missing');
    wrapper.textContent = altText;
    img.remove();
  });

  wrapper.appendChild(img);
  return wrapper;
}
