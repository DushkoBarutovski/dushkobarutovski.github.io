// =====================================================
// Project detail page
// Reads ?id=... from the URL to find the right project in
// PROJECTS (data.js), then displays its renders one at a time
// alongside the project's story and a per-render description.
// =====================================================
const params = new URLSearchParams(window.location.search);
const requestedId = params.get('id');
const project = PROJECTS.find((p) => p.id === requestedId) || PROJECTS[0];

let renderIndex = 0;

const titleEl = document.getElementById('project-title');
const storyText = document.getElementById('story-text');
const descriptionText = document.getElementById('render-description');
const viewerEl = document.getElementById('render-viewer');
const dotsContainer = document.getElementById('render-dots');
const prevBtn = document.getElementById('render-prev');
const nextBtn = document.getElementById('render-next');

function init() {
  document.title = `${project.name} | Your Name`;
  titleEl.textContent = project.name;
  storyText.textContent = project.story;
  renderDots();
  showRender(0);
}

function showRender(index) {
  renderIndex = (index + project.renders.length) % project.renders.length;
  const render = project.renders[renderIndex];

  viewerEl.classList.remove('img-missing');
  viewerEl.innerHTML = '';

  // A blurred copy of the same image fills the space around a
  // portrait render instead of leaving plain white on the sides —
  // a simple stand-in for "matching colours" that works for any image.
  const renderBackdrop = document.createElement('div');
  renderBackdrop.className = 'render-backdrop';

  const img = document.createElement('img');
  img.className = 'render-main-image';
  img.src = render.image;
  img.alt = `${project.name} — render ${renderIndex + 1}`;

  img.addEventListener('load', () => {
    const isPortrait = img.naturalHeight > img.naturalWidth;
    if (isPortrait) {
      renderBackdrop.style.backgroundImage = `url(${render.image})`;
      renderBackdrop.classList.add('active');
    }
  });

  img.addEventListener('error', () => {
    viewerEl.classList.add('img-missing');
    viewerEl.textContent = `${project.name} — render ${renderIndex + 1}`;
  });

  viewerEl.appendChild(renderBackdrop);
  viewerEl.appendChild(img);

  descriptionText.textContent = render.description;
  updateDots();
}

function renderDots() {
  dotsContainer.innerHTML = '';
  project.renders.forEach((_, i) => {
    const dot = document.createElement('button');
    dot.type = 'button';
    dot.className = 'render-dot';
    dot.setAttribute('aria-label', `Show render ${i + 1}`);
    dot.addEventListener('click', () => showRender(i));
    dotsContainer.appendChild(dot);
  });
}

function updateDots() {
  [...dotsContainer.children].forEach((dot, i) => {
    dot.classList.toggle('active', i === renderIndex);
  });
}

prevBtn.addEventListener('click', () => showRender(renderIndex - 1));
nextBtn.addEventListener('click', () => showRender(renderIndex + 1));

document.addEventListener('keydown', (event) => {
  if (event.key === 'ArrowLeft') showRender(renderIndex - 1);
  if (event.key === 'ArrowRight') showRender(renderIndex + 1);
});

init();
